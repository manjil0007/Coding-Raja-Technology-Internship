# Embed MusicApp

Embed this music player to any website:

```html
<iframe src="https://samirpaulb.github.io/music/embed"
	title="Embed MusicApp"
	frameborder="0"
	loading="lazy"
	marginheight="0"
	marginwidth="0"
	width="100%"
	height="223"
	scrolling="no">
</iframe>
```
