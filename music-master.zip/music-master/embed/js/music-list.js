// To add more song, just copy the following code and paste inside the array

//   {
//     name: "Here is the music name",
//     artist: "Here is the artist name",
//     img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
//     src: "music name here - remember img must be in .mp3 formate and it's inside the https://github.com/samir-paul/audio/ folder."
//   }

//paste it inside the array as more as you want music then you don't need to do any other thing

let allMusic = [
  {
    name: "Lofi Study Music 1",
    artist: "Unknown",
    img: "music-1",
    src: "music-1"
  },
  {
    name: "Lofi Study Music 2",
    artist: "Unknown",
    img: "music-2",
    src: "music-2"
  },
  {
    name: "Lofi Study Music 3",
    artist: "Unknown",
    img: "music-3",
    src: "music-3"
  },
  {
    name: "Lofi Study Music 4",
    artist: "Unknown",
    img: "music-4",
    src: "music-4"
  },
  {
    name: "Lofi Study Music 5",
    artist: "Unknown",
    img: "music-5",
    src: "music-5"
  },
  {
    name: "Lofi Study Music 6",
    artist: "Unknown",
    img: "music-6",
    src: "music-6"
  },
  {
    name: "Lofi Study Music 7",
    artist: "Unknown",
    img: "music-7",
    src: "music-7"
  },
  {
    name: "Lofi Study Music 8",
    artist: "Unknown",
    img: "music-8",
    src: "music-8"
  },
  


  // like this paste it and remember to give comma after ending of this bracket }
  // {
  //   name: "Here is the music name",
  //   artist: "Here is the artist name",
  //   img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
  //   src: "music name here - remember img must be in .mp3 formate and it's inside the songs folder of this project folder"
  // }
];
