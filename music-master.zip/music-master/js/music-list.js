// To add more song, just copy the following code and paste inside the array

//   {
//     name: "Here is the music name",
//     artist: "Here is the artist name",
//     img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
//     src: "music name here - remember img must be in .mp3 formate and it's inside the https://github.com/SamirPaulb/assets/tree/main/music/ folder."
//   }

//paste it inside the array as more as you want music then you don't need to do any other thing

let allMusic = [
  {
    name: "Harley Bird - Home",
    artist: "Jordan Schor",
    img: "music-1",
    src: "music-1"
  },
  {
    name: "Ikson Anywhere – Ikson",
    artist: "Audio Library",
    img: "music-2",
    src: "music-2"
  },
  {
    name: "Beauz & Jvna - Crazy",
    artist: "Beauz & Jvna",
    img: "music-3",
    src: "music-3"
  },
  {
    name: "Hardwind - Want Me",
    artist: "Mike Archangelo",
    img: "music-4",
    src: "music-4"
  },
  {
    name: "Jim - Sun Goes Down",
    artist: "Jim Yosef x Roy",
    img: "music-5",
    src: "music-5"
  },
  {
    name: "Lost Sky - Vision NCS",
    artist: "NCS Release",
    img: "music-6",
    src: "music-6"
  },
  {
    name: "Alan Walker - Faded",
    artist: "ImanbekMusic",
    img: "music-7",
    src: "music-7"
  },
  {
    name: "Feat.Au/Ra and Tomine Harket",
    artist: "Alan Walker",
    img: "music-8",
    src: "music-8"
  },
  {
    name: "MIC Drop(Steve Aoki Remix)",
    artist: "HYBE LABELS",
    img: "music-9",
    src: "music-9"
  },
  {
    name: "BTS(방탄소년단)'Butter' ",
    artist: "HYBE LABELS",
    img: "music-10",
    src: "music-10"
  },
  {
    name: "BTS(방탄소년단)'Dynamite' ",
    artist: "HYBE LABELS",
    img: "music-11",
    src: "music-11"
  },
  {
    name: "DAOKO×Kenshi Yonezu -Fireworks",
    artist: "Daoko",
    img: "music-12",
    src: "music-12"
  },
  {
    name: "Teri Mitti - Kesari ",
    artist: " Zee Music Company",
    img: "music-13",
    src: "music-13"
  },
  {
    name: "KHAIRIYAT(BONUS TRACK)-CHHICHHORE",
    artist: "T-Series",
    img: "music-14",
    src: "music-14"
  },
  {
    name: "Waka Waka(This Time for Africa)",
    artist: "Shakira",
    img: "music-15",
    src: "music-15"
  },
  {
    name: "Phao-2 Phut Hon(KAIZ Remix)",
    artist: "Light Night Music",
    img: "music-16",
    src: "music-16"
  },
  {
    name: "スパークル - Your name",
    artist: "Radwimps",
    img: "music-17",
    src: "music-17"
  },
  {
    name: "Ed Sheeran - Shape of You",
    artist: "Ed Sheeran",
    img: "music-18",
    src: "music-18"
  },
  {
    name: "Sia - Unstoppable ",
    artist: "Loku",
    img: "music-19",
    src: "music-19"
  },
  {
    name: "Bhaag Milkha Bhaag - Zinda ",
    artist: "SonyMusicIndiaVEVO",
    img: "music-20",
    src: "music-20"
  },


  // like this paste it and remember to give comma after ending of this bracket }
  // {
  //   name: "Here is the music name",
  //   artist: "Here is the artist name",
  //   img: "image name here - remember img must be in .jpg formate and it's inside the images folder of this project folder",
  //   src: "music name here - remember img must be in .mp3 formate and it's inside the songs folder of this project folder"
  // }
];